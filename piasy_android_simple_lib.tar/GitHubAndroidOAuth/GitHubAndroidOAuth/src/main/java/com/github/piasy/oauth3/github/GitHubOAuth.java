package com.github.piasy.oauth3.github;

/**
 * Created by Piasy{github.com/Piasy} on 25/12/2016.
 */

public abstract class GitHubOAuth {

    public static void hello() {
        System.out.println("Hello");
    }
}
