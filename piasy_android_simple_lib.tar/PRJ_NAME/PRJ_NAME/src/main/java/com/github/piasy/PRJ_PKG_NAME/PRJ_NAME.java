package com.github.piasy.PRJ_PKG_NAME;

/**
 * Created by Piasy{github.com/Piasy} on 25/12/2016.
 */

public class PRJ_NAME {
}
